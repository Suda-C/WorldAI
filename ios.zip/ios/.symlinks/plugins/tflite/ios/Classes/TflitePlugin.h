#import <Flutter/Flutter.h>

@interface TflitePlugin : NSObject<FlutterPlugin>
@end
